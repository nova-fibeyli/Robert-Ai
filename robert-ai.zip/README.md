# Robert-Ai: Empathic Emotional Support Robo Friend

## Overview

Robert-Ai is designed to provide empathetic emotional support, leveraging AI to engage in meaningful conversations.

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/robert-ai.git
   cd robert-ai
   ```

2. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

Run the application using Streamlit:
```bash
streamlit run src/app.py
```

## Examples

Ask a question like:
> "How are you feeling today?"

The bot will respond empathetically based on its training data and conversational models.

## License

This project is licensed under the MIT License. See the LICENSE file for details.
